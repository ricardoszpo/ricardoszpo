package com.example.matriz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mat, det;
    EditText m00, m01, m02, m10, m11, m12, m20, m21, m22;
    //int[][] numeros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        mat = findViewById(R.id.mat);
        det = findViewById(R.id.det);
        m00 = findViewById(R.id.m00);
        m01 = findViewById(R.id.m01);
        m02 = findViewById(R.id.m02);
        m10 = findViewById(R.id.m10);
        m11 = findViewById(R.id.m11);
        m12 = findViewById(R.id.m12);
        m20 = findViewById(R.id.m20);
        m21 = findViewById(R.id.m21);
        m22 = findViewById(R.id.m22);
        //criarMatriz();
    }
   /* public void criarMatriz(){
        String matriz = "Matriz\n";
        for (int linha = 0; linha < 3; linha++){
            for(int coluna = 0; coluna < 3; coluna ++){
                matriz += numeros[linha] [coluna]+" ";

            }
            matriz += "\n";
        }
        mat.setText(matriz);

    }*/

    public void determinante(View v){

        int a = Integer.parseInt(String.valueOf(m00.getText()));
        //numeros[0][0] = a;
        int b = Integer.parseInt(String.valueOf(m10.getText()));
        //numeros[1][0] = b;
        int c = Integer.parseInt(String.valueOf(m20.getText()));
        //numeros[2][0] = c;
        int d = Integer.parseInt(String.valueOf(m01.getText()));
        //numeros[0][1] = d;
        int e = Integer.parseInt(String.valueOf(m11.getText()));
       // numeros[1][1] = e;
        int f = Integer.parseInt(String.valueOf(m21.getText()));
        //numeros[2][1] = f;
        int g = Integer.parseInt(String.valueOf(m02.getText()));
       // numeros[0][2] = g;
        int h = Integer.parseInt(String.valueOf(m12.getText()));
        //numeros[1][2] = h;
        int i = Integer.parseInt(String.valueOf(m22.getText()));
        //numeros[2][2] = i;

        int res = (a*e*i)+(d*h*c)+(g*b*f)-(c*e*g)-(f*h*a)-(i*b*d);
        det.setText(res+"");

    }

}
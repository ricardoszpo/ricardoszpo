package com.example.urna;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText ccpf, numcandidato;
    ArrayList<Candidato> lCandidatos = new ArrayList<>();
    ArrayList<String> lCpfs = new ArrayList<>();
    TextView nome, cargo;
    Candidato cand = new Candidato();
    boolean jaVotou = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        ccpf = findViewById(R.id.cpfeleitor);
        numcandidato = findViewById(R.id.numcandidato);
        nome = findViewById(R.id.nome);
        cargo = findViewById(R.id.cargo);
        //criarCandidatos();
    }

    public void criarCandidatos() {
        Candidato batata = new Candidato("Batata", "Presidente", "27", 0);
        batata.salvarBD();
        lCandidatos.add(batata);
        Candidato milkshake = new Candidato("Milkshake", "Presidente", "19", 0);
        milkshake.salvarBD();
        lCandidatos.add(batata);
        Candidato tainha = new Candidato("Tainha", "Presidente", "50", 0);
        tainha.salvarBD();
        lCandidatos.add(batata);
        Candidato nescau = new Candidato("Nescau", "Presidente", "72", 0);
        nescau.salvarBD();
        lCandidatos.add(batata);
        Candidato nulo = new Candidato("nulo", "", "", 0);
        nulo.salvarBD();
        lCandidatos.add(batata);
    }

    public void verifica(View v) {
        DatabaseReference referenceCpf = FirebaseDatabase.getInstance().getReference().child("CPFs");
        referenceCpf.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean valida = false;
                String eleitor = ccpf.getText().toString();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    String CPF = ds.getValue(String.class);
                    if (CPF.equals(eleitor) && !eleitor.equals(null) && !eleitor.equals("")) {
                        valida = true;
                        break;
                    }
                }
                if (valida) {
                    Toast.makeText(MainActivity.this, "Eleitor já votou!", Toast.LENGTH_SHORT).show();
                } else {
                    verificaCandidato();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    public void salvarCpf(String CPF) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        ref.child("CPFs").child(String.valueOf(CPF)).setValue(CPF);

    }

    public void confirma(View v) {
        String ccargo = cargo.getText() + "";
        String cnome = nome.getText() + "";
        if (!ccargo.equals("Cargo:") && !cnome.equals("Nome:") && !ccpf.getText().toString().equals(null) && !ccpf.getText().toString().equals("")) {
            numcandidato.setText("");
            Toast.makeText(MainActivity.this, cand.getNome(), Toast.LENGTH_SHORT).show();
            cand.setQuantvotos(cand.getQuantvotos() + 1);
            cand.salvarBD();
            salvarCpf(ccpf.getText().toString());
            ccpf.setText("");
            nome.setText("Nome:");
            cargo.setText("Cargo:");
            restartActivity();

        } else {
            Toast.makeText(MainActivity.this, "Verifique as informações antes de confirmar", Toast.LENGTH_SHORT).show();

        }

    }
    public void restartActivity(){
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }


    public void verificaCandidato() {
        String cnumero = numcandidato.getText() + "";
        DatabaseReference referenceCandidato = FirebaseDatabase.getInstance().getReference().child("Candidato");
        referenceCandidato.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Candidato candidato = ds.getValue(Candidato.class);
                    String numero = candidato.getNumero();
                    if (cnumero.equals(numero)) {
                        nome.setText(candidato.getNome());
                        cargo.setText(candidato.getCargo());
                        cand = candidato;
                        break;
                    } else {
                        nome.setText(candidato.getNome());
                        cargo.setText(candidato.getCargo());
                        cand = candidato;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
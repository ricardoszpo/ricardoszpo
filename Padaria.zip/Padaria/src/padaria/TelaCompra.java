// ===================  ======          ======
// ==================== ======        ======
//              ======  ======      ======
//            ======    ======    ======
//          ======      ======  ======
//        ======        ============
//      ======          ============
//    ======            ======  ======
//  ======              ======    ======
// ======               ======      ======
// ===================  ======        ======
// ==================== ======          ======
//
// DEVELOPED BY ZK#6666

package padaria;

import javax.swing.JOptionPane;

public class TelaCompra extends javax.swing.JFrame {

    public TelaCompra() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        Campofunccompra = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Campodatacompra = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Campocpfcompra = new javax.swing.JTextField();
        Campototalcompra = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        CadastrarCompra = new javax.swing.JButton();
        PesquisarCompra = new javax.swing.JButton();
        ExcluirCompra = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel5.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel5.setText("Data:");

        Campofunccompra.setFont(new java.awt.Font("Arial", 0, 12)); 
        Campofunccompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampofunccompraActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 1, 20)); 
        jLabel1.setText("COMPRA:");

        Campodatacompra.setFont(new java.awt.Font("Arial", 0, 12));
        Campodatacompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampodatacompraActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel3.setText("CPF cliente:");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel4.setText("Funcionário: ");

        Campocpfcompra.setFont(new java.awt.Font("Arial", 0, 12)); 
        Campocpfcompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampocpfcompraActionPerformed(evt);
            }
        });

        Campototalcompra.setFont(new java.awt.Font("Arial", 0, 12)); 
        Campototalcompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampototalcompraActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel6.setText("Total compra:");

        CadastrarCompra.setFont(new java.awt.Font("Arial", 0, 12));
        CadastrarCompra.setText("CADASTRAR");
        CadastrarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarCompraActionPerformed(evt);
            }
        });

        PesquisarCompra.setFont(new java.awt.Font("Arial", 0, 12)); 
        PesquisarCompra.setText("PESQUISAR");
        PesquisarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PesquisarCompraActionPerformed(evt);
            }
        });

        ExcluirCompra.setFont(new java.awt.Font("Arial", 0, 12)); 
        ExcluirCompra.setText("EXCLUIR");
        ExcluirCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirCompraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(14, 14, 14)
                        .addComponent(Campocpfcompra))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Campofunccompra, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CadastrarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PesquisarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ExcluirCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(10, 10, 10)
                        .addComponent(Campodatacompra, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Campototalcompra, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Campocpfcompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(Campofunccompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Campodatacompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(Campototalcompra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CadastrarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ExcluirCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PesquisarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        pack();
    }

    private void CampofunccompraActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void CampodatacompraActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void CampocpfcompraActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void CampototalcompraActionPerformed(java.awt.event.ActionEvent evt) {
       
    }

    private void CadastrarCompraActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocpfcompra.getText().equals("") || Campodatacompra.getText().equals("") || Campofunccompra.getText().equals("") || Campototalcompra.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha os campos corretamente");
        } else {
            try{
        Compras c = new Compras(Campocpfcompra.getText(), Campodatacompra.getText(), Double.parseDouble(Campototalcompra.getText()), Campofunccompra.getText());
        AcessoBD_padaria.salvar_compra(c);
        Campocpfcompra.setText("");
        Campodatacompra.setText("");
        Campofunccompra.setText("");
        Campototalcompra.setText("");
            JOptionPane.showMessageDialog(this, "Compra cadastrada!");

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Compra não cadastrada!");
            }
        }
    }

    private void PesquisarCompraActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocpfcompra.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha o campo cpf");
        } else if(AcessoBD_padaria.pesquisa_compra("compra", Campocpfcompra.getText()) != true){
            JOptionPane.showMessageDialog(this, "Compra não cadastrada");
        }
        else if(AcessoBD_padaria.pesquisa_compra("compra", Campocpfcompra.getText()) == true){
            AcessoBD_padaria.pesquisa_compra("compra", Campocpfcompra.getText());
        }
    }

    private void ExcluirCompraActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocpfcompra.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha o campo cpf corretamente");
        }
        else {
            try{
            AcessoBD_padaria.deleta_compra(Campocpfcompra.getText());
            JOptionPane.showMessageDialog(this, "Compra deletada");
        }
            catch(Exception e){
                JOptionPane.showMessageDialog(this, "Compra não deletada");
            }
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaCompra.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaCompra().setVisible(true);
            }
        });
    }

    private javax.swing.JButton CadastrarCompra;
    private javax.swing.JTextField Campocpfcompra;
    private javax.swing.JTextField Campodatacompra;
    private javax.swing.JTextField Campofunccompra;
    private javax.swing.JTextField Campototalcompra;
    private javax.swing.JButton ExcluirCompra;
    private javax.swing.JButton PesquisarCompra;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
}

// ===================  ======          ======
// ==================== ======        ======
//              ======  ======      ======
//            ======    ======    ======
//          ======      ======  ======
//        ======        ============
//      ======          ============
//    ======            ======  ======
//  ======              ======    ======
// ======               ======      ======
// ===================  ======        ======
// ==================== ======          ======
//
// DEVELOPED BY ZK#6666
package padaria;

import javax.swing.JOptionPane;

public class TelaEstoque extends javax.swing.JFrame {

    public TelaEstoque() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Campocodprod = new javax.swing.JTextField();
        Campocodfilial = new javax.swing.JTextField();
        ExcluirEstoque = new javax.swing.JButton();
        cadastrarEstoque = new javax.swing.JButton();
        PesquisarEstoque = new javax.swing.JButton();

        jLabel4.setText("jLabel4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 20)); 
        jLabel1.setText("ESTOQUE:");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel2.setText("Código produto:");

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel3.setText("Código da filial:");

        Campocodprod.setFont(new java.awt.Font("Arial", 0, 12));
        Campocodprod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampocodprodActionPerformed(evt);
            }
        });

        Campocodfilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        Campocodfilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampocodfilialActionPerformed(evt);
            }
        });

        ExcluirEstoque.setFont(new java.awt.Font("Arial", 0, 12));
        ExcluirEstoque.setText("EXCLUIR");
        ExcluirEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirEstoqueActionPerformed(evt);
            }
        });

        cadastrarEstoque.setFont(new java.awt.Font("Arial", 0, 12)); 
        cadastrarEstoque.setText("CADASTRAR");
        cadastrarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarEstoqueActionPerformed(evt);
            }
        });

        PesquisarEstoque.setFont(new java.awt.Font("Arial", 0, 12)); 
        PesquisarEstoque.setText("PESQUISAR");
        PesquisarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PesquisarEstoqueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Campocodprod))
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addGap(10, 10, 10)
                            .addComponent(Campocodfilial, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addComponent(cadastrarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(PesquisarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(ExcluirEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Campocodprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Campocodfilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cadastrarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ExcluirEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PesquisarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        pack();
    }

    private void CampocodprodActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void CampocodfilialActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void cadastrarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocodfilial.getText().equals("") || Campocodprod.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha os campos corretamente");
        } else {
            try{
        Estoque e = new Estoque(Integer.parseInt(Campocodprod.getText()), Campocodfilial.getText());
        AcessoBD_padaria.salvar_estoque(e);
        Campocodprod.setText("");
        Campocodfilial.setText("");
            JOptionPane.showMessageDialog(this, "Estoque cadastrado!");

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Problamas com a filial!");
            }
        }
    }

    private void PesquisarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocodprod.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha os campos corretamente");
        } else if(AcessoBD_padaria.pesquisa_estoque("estoque", Integer.parseInt(Campocodprod.getText()), Campocodfilial.getText()) != true){
            JOptionPane.showMessageDialog(this, "Estoque não cadastrado");
        }
        else if(AcessoBD_padaria.pesquisa_estoque("estoque", Integer.parseInt(Campocodprod.getText()), Campocodfilial.getText()) == true){
            AcessoBD_padaria.pesquisa_estoque("produto", Integer.parseInt(Campocodprod.getText()), Campocodfilial.getText());
        }
    }

    private void ExcluirEstoqueActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocodprod.getText().equals("") || Campocodfilial.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha os campos de código corretamente");
        }
        else {
            try{
            AcessoBD_padaria.deleta_estoque(Integer.parseInt(Campocodprod.getText()), Campocodfilial.getText());
            JOptionPane.showMessageDialog(this, "Estoque deletado");
            }
             catch(Exception e){
                JOptionPane.showMessageDialog(this, "Estoque não deletado");
                }
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaEstoque().setVisible(true);
            }
        });
    }

    private javax.swing.JTextField Campocodfilial;
    private javax.swing.JTextField Campocodprod;
    private javax.swing.JButton ExcluirEstoque;
    private javax.swing.JButton PesquisarEstoque;
    private javax.swing.JButton cadastrarEstoque;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
}

// ===================  ======          ======
// ==================== ======        ======
//              ======  ======      ======
//            ======    ======    ======
//          ======      ======  ======
//        ======        ============
//      ======          ============
//    ======            ======  ======
//  ======              ======    ======
// ======               ======      ======
// ===================  ======        ======
// ==================== ======          ======
//
// DEVELOPED BY ZK#6666
package padaria;

import java.awt.Color;
import javax.swing.JOptionPane;

public class TelaFilial extends javax.swing.JFrame {

    public TelaFilial() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Campocidadefilial = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        Campocodfilial = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        camponomefilial = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        Campoestadofilial = new javax.swing.JTextField();
        ExcluirFilial = new javax.swing.JButton();
        CadastrarFilial = new javax.swing.JButton();
        PesquisarFilial = new javax.swing.JButton();

        jButton3.setFont(new java.awt.Font("Arial", 0, 12)); 
        jButton3.setText("EXCLUIR");

        jButton4.setFont(new java.awt.Font("Arial", 0, 12)); 
        jButton4.setText("CADASTRAR");

        jButton5.setFont(new java.awt.Font("Arial", 0, 12)); 
        jButton5.setText("PESQUISAR");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 20)); 
        jLabel1.setText("FILIAL:");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel2.setText("Código:");

        Campocidadefilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        Campocidadefilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampocidadefilialActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel3.setText("Nome:");

        Campocodfilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        Campocodfilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampocodfilialActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); 
        jLabel4.setText("Estado:");

        camponomefilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        camponomefilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                camponomefilialActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial", 0, 14));
        jLabel5.setText("Cidade:");

        Campoestadofilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        Campoestadofilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CampoestadofilialActionPerformed(evt);
            }
        });

        ExcluirFilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        ExcluirFilial.setText("EXCLUIR");
        ExcluirFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExcluirFilialActionPerformed(evt);
            }
        });

        CadastrarFilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        CadastrarFilial.setText("CADASTRAR");
        CadastrarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CadastrarFilialActionPerformed(evt);
            }
        });

        PesquisarFilial.setFont(new java.awt.Font("Arial", 0, 12));
        PesquisarFilial.setText("PESQUISAR");
        PesquisarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PesquisarFilialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CadastrarFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(PesquisarFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ExcluirFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Campocidadefilial, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Campoestadofilial))
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(camponomefilial)
                            .addComponent(Campocodfilial))))
                .addGap(0, 36, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Campocodfilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(camponomefilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(Campoestadofilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Campocidadefilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CadastrarFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ExcluirFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PesquisarFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        pack();
    }

    private void CampocidadefilialActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void CampocodfilialActionPerformed(java.awt.event.ActionEvent evt) {
       
    }

    private void camponomefilialActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void CampoestadofilialActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void CadastrarFilialActionPerformed(java.awt.event.ActionEvent evt) {
        if (camponomefilial.getText().equals("") || Campocodfilial.getText().equals("") || Campoestadofilial.getText().equals("") || Campocidadefilial.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha os campos corretamente");
        } else {
            try {
                Filial fi = new Filial(Campocodfilial.getText(), camponomefilial.getText(), Campocidadefilial.getText(), Campoestadofilial.getText());
                AcessoBD_padaria.salvar_filial(fi); 
                Campocodfilial.setText("");
                camponomefilial.setText("");
                Campoestadofilial.setText("");
                Campocidadefilial.setText("");
                JOptionPane.showMessageDialog(this, "Filial cadastrada!");
        }
            catch (Exception e){
                JOptionPane.showMessageDialog(this, "Filial não cadastrada!");
            }
        }
    }

    private void PesquisarFilialActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocodfilial.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha o campo código");
        } else if(AcessoBD_padaria.pesquisa_filial("filial", Campocodfilial.getText()) != true){
            JOptionPane.showMessageDialog(this, "Filial não cadastrada");
        }
        else if(AcessoBD_padaria.pesquisa_filial("filial", Campocodfilial.getText()) == true){
            AcessoBD_padaria.pesquisa_filial("filial", Campocodfilial.getText());
        }
    }

    private void ExcluirFilialActionPerformed(java.awt.event.ActionEvent evt) {
        if (Campocodfilial.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Preencha o campo código corretamente");
        }
        else {
            try{
                if (AcessoBD_padaria.deleta_filial(Campocodfilial.getText()) == true){
                    AcessoBD_padaria.deleta_filial(Campocodfilial.getText());
                    JOptionPane.showMessageDialog(this, "Filial deletada");
                }
                else if (AcessoBD_padaria.deleta_filial(Campocodfilial.getText()) != true){
                    JOptionPane.showMessageDialog(this, "Filial utilizada em outra tabela");
                }
        }
            catch(Exception e){
                JOptionPane.showMessageDialog(this, "Filial não deletada");
            }
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
    }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaFilial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaFilial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaFilial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaFilial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaFilial().setVisible(true);
            }
        });
    }

    private javax.swing.JButton CadastrarFilial;
    private javax.swing.JTextField Campocidadefilial;
    private javax.swing.JTextField Campocodfilial;
    private javax.swing.JTextField Campoestadofilial;
    private javax.swing.JButton ExcluirFilial;
    private javax.swing.JButton PesquisarFilial;
    private javax.swing.JTextField camponomefilial;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
}

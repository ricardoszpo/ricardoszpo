// ===================  ======          ======
// ==================== ======        ======
//              ======  ======      ======
//            ======    ======    ======
//          ======      ======  ======
//        ======        ============
//      ======          ============
//    ======            ======  ======
//  ======              ======    ======
// ======               ======      ======
// ===================  ======        ======
// ==================== ======          ======
//
// DEVELOPED BY ZK#6666
package padaria;

import java.awt.Color;

public class TelaInicio extends javax.swing.JFrame {

    public TelaInicio() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        AcessarCompra = new javax.swing.JButton();
        AcessarFilial = new javax.swing.JButton();
        AcessarFornec = new javax.swing.JButton();
        AcessarEstoque = new javax.swing.JButton();
        AcessarProd = new javax.swing.JButton();
        AcessarFunc = new javax.swing.JButton();
        VisualizarFornec = new javax.swing.JButton();
        VisualizarEstoque = new javax.swing.JButton();
        VisualizarProd = new javax.swing.JButton();
        VisulizarFunc = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        VisulizarCompra = new javax.swing.JButton();
        VisualizarFilial = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 20)); 
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Acessar o banco:");

        AcessarCompra.setFont(new java.awt.Font("Arial", 0, 12)); 
        AcessarCompra.setText("COMPRA");
        AcessarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcessarCompraActionPerformed(evt);
            }
        });

        AcessarFilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        AcessarFilial.setText("FILIAL");
        AcessarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcessarFilialActionPerformed(evt);
            }
        });

        AcessarFornec.setFont(new java.awt.Font("Arial", 0, 12)); 
        AcessarFornec.setText("FORNECEDOR");
        AcessarFornec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcessarFornecActionPerformed(evt);
            }
        });

        AcessarEstoque.setFont(new java.awt.Font("Arial", 0, 12)); 
        AcessarEstoque.setText("ESTOQUE");
        AcessarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcessarEstoqueActionPerformed(evt);
            }
        });

        AcessarProd.setFont(new java.awt.Font("Arial", 0, 12)); 
        AcessarProd.setText("PRODUTO");
        AcessarProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcessarProdActionPerformed(evt);
            }
        });

        AcessarFunc.setFont(new java.awt.Font("Arial", 0, 12)); 
        AcessarFunc.setText("FUNCIONÁRIO");
        AcessarFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AcessarFuncActionPerformed(evt);
            }
        });

        VisualizarFornec.setFont(new java.awt.Font("Arial", 0, 12)); 
        VisualizarFornec.setText("FORNECEDOR");
        VisualizarFornec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VisualizarFornecActionPerformed(evt);
            }
        });

        VisualizarEstoque.setFont(new java.awt.Font("Arial", 0, 12)); 
        VisualizarEstoque.setText("ESTOQUE");
        VisualizarEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VisualizarEstoqueActionPerformed(evt);
            }
        });

        VisualizarProd.setFont(new java.awt.Font("Arial", 0, 12)); 
        VisualizarProd.setText("PRODUTO");
        VisualizarProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VisualizarProdActionPerformed(evt);
            }
        });

        VisulizarFunc.setFont(new java.awt.Font("Arial", 0, 12)); 
        VisulizarFunc.setText("FUNCIONÁRIO");
        VisulizarFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VisulizarFuncActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial", 1, 20)); 
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Visualizar o banco:");

        VisulizarCompra.setFont(new java.awt.Font("Arial", 0, 12)); 
        VisulizarCompra.setText("COMPRA");
        VisulizarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VisulizarCompraActionPerformed(evt);
            }
        });

        VisualizarFilial.setFont(new java.awt.Font("Arial", 0, 12)); 
        VisualizarFilial.setText("FILIAL");
        VisualizarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VisualizarFilialActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AcessarFunc, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AcessarProd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AcessarCompra, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AcessarFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AcessarFornec, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AcessarEstoque, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(VisulizarFunc, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(VisualizarProd, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(VisualizarEstoque, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(VisualizarFornec, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(VisualizarFilial, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(VisulizarCompra, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(60, 60, 60))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(39, 39, 39)
                        .addComponent(VisualizarFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(VisualizarFornec, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(VisualizarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(VisualizarProd, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(VisulizarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(VisulizarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(39, 39, 39)
                        .addComponent(AcessarFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(AcessarFornec, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(AcessarEstoque, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(AcessarProd, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(AcessarFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(AcessarCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
    }

    private void AcessarCompraActionPerformed(java.awt.event.ActionEvent evt) {
        TelaCompra compra = new TelaCompra();
        compra.setVisible(true);
    }

    private void AcessarFilialActionPerformed(java.awt.event.ActionEvent evt) {
        TelaFilial filial = new TelaFilial();
        filial.setVisible(true);
    }

    private void AcessarFornecActionPerformed(java.awt.event.ActionEvent evt) {
        TelaFornecedor fornecedor = new TelaFornecedor();
        fornecedor.setVisible(true);
    }

    private void AcessarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {
        TelaEstoque estoque = new TelaEstoque();
        estoque.setVisible(true);
    }

    private void AcessarProdActionPerformed(java.awt.event.ActionEvent evt) {
        TelaProduto produto = new TelaProduto();
        produto.setVisible(true);
    }

    private void AcessarFuncActionPerformed(java.awt.event.ActionEvent evt) {
        TelaFuncionario funcionario = new TelaFuncionario();
        funcionario.setVisible(true);
    }

    private void VisualizarFornecActionPerformed(java.awt.event.ActionEvent evt) {
        AcessoBD_padaria.visualiza_tabela("fornecedor", "cnpj", "nome", "email", "estado", "produto");
    }

    private void VisualizarEstoqueActionPerformed(java.awt.event.ActionEvent evt) {
        AcessoBD_padaria.visualiza_estoque("cidade", "estado", "nome", "marca", "descricao", "qtd", "validade");
    }

    private void VisualizarProdActionPerformed(java.awt.event.ActionEvent evt) {
        AcessoBD_padaria.visualiza_tabela("produto", "codigo_produto", "validade", "qtd", "data_compra", "cod_fornecedor", "marca", "preco", "descricao");
    }

    private void VisulizarFuncActionPerformed(java.awt.event.ActionEvent evt) {
        AcessoBD_padaria.visualiza_tabela("funcionarios_padaria", "pis", "nome", "salario", "cargo", "carga_horaria", "cod_filial");
    }

    private void VisulizarCompraActionPerformed(java.awt.event.ActionEvent evt) {
        AcessoBD_padaria.visualiza_tabela("compra", "cpf_cliente", "data_compra", "total", "cod_func");
    }

    private void VisualizarFilialActionPerformed(java.awt.event.ActionEvent evt) {
        AcessoBD_padaria.visualiza_tabela("filial", "cod", "nome", "cidade", "estado");
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaInicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaInicio().setVisible(true);
            }
        });
    }

    private javax.swing.JButton AcessarCompra;
    private javax.swing.JButton AcessarEstoque;
    private javax.swing.JButton AcessarFilial;
    private javax.swing.JButton AcessarFornec;
    private javax.swing.JButton AcessarFunc;
    private javax.swing.JButton AcessarProd;
    private javax.swing.JButton VisualizarEstoque;
    private javax.swing.JButton VisualizarFilial;
    private javax.swing.JButton VisualizarFornec;
    private javax.swing.JButton VisualizarProd;
    private javax.swing.JButton VisulizarCompra;
    private javax.swing.JButton VisulizarFunc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
}

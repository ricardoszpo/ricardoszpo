package padaria;

public class padaria {

    public static void main(String[] args) {
        TelaInicio inicio = new TelaInicio();
        inicio.setVisible(true);
    }
}